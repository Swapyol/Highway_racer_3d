# Highway Racer 3D — Android build kit

This package wraps the existing HTML/Three.js prototype in a Capacitor Android app and uses GitHub Actions to build a **debug APK** without needing a PC.

## Build from an Android phone (free tools)

1. Download and extract this ZIP.
2. In Chrome, sign in to GitHub and create a **new public repository** named `highway-racer-3d`. A public repo makes it easier to use GitHub Actions on the free plan; check current GitHub usage limits.
3. Upload the extracted files and folders to the repository root. Make sure `package.json`, `capacitor.config.json`, `www/`, and `.github/workflows/build-android.yml` are at the root.
4. Open the repository's **Actions** tab.
5. Select **Build Highway Racer Android APK** and tap **Run workflow**.
6. Wait for the run to finish successfully.
7. Open that completed run and download the artifact named `highway-racer-debug-apk`.
8. Extract the artifact ZIP on your phone and tap `app-debug.apk` to install it. Android may ask you to allow installs from your browser or file manager.

## Important notes

- This workflow creates a **debug APK for testing**, not a Google Play release AAB.
- The current game loads Three.js from a CDN, so an internet connection is needed when the game runs.
- The package ID is currently `com.swapnil.highwayracer`. Change it before release if you prefer a different unique ID. Do not change the ID after publishing.
- Keep your source repository public only if you're comfortable making the game code public.
- Before Google Play release, bundle the 3D library locally, test on real devices, add app icons/versioning, create a signed release build/AAB, and review current Play Console requirements.
- The build workflow and project have been prepared but have not been executed here; the first GitHub Actions run will confirm whether the build succeeds.
